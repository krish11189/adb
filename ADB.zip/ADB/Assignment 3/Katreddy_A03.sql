--Question 1
CREATE TABLE time_e (
    time_id VARCHAR2(10),
    day     NUMBER(2),
    month   NUMBER(3),
    quarter NUMBER(1),
    year    NUMBER(4),
    CONSTRAINT time_primary_key PRIMARY KEY ( time_id )
);

CREATE TABLE branch (
    branch_id   VARCHAR2(10),
    branch_name VARCHAR2(15),
    branch_type VARCHAR2(10),
    CONSTRAINT branch_primary_key PRIMARY KEY ( branch_id )
);

CREATE TABLE item (
    item_id       VARCHAR2(10),
    item_name     VARCHAR2(15),
    brand         VARCHAR2(15),
    type          VARCHAR2(10),
    supplier_type VARCHAR2(10),
    CONSTRAINT item_primary_key PRIMARY KEY ( item_id )
);

CREATE TABLE location (
    location_id VARCHAR2(10),
    street      VARCHAR2(10),
    city        VARCHAR2(10),
    state       VARCHAR2(10),
    country     VARCHAR2(10),
    CONSTRAINT location_primary_key PRIMARY KEY ( location_id )
);

CREATE TABLE sales (
    branch_id    VARCHAR2(10),
    location_id  VARCHAR2(10),
    item_id      VARCHAR2(10),
    time_id      VARCHAR2(10),
    units_sold   NUMBER(10),
    dollars_sold NUMBER(10),
    CONSTRAINT sales_primary_key PRIMARY KEY ( branch_id,
                                               location_id,
                                               item_id,
                                               time_id ),
    CONSTRAINT sales_branch_fk FOREIGN KEY ( branch_id )
        REFERENCES branch ( branch_id ),
    CONSTRAINT time_branch_fk FOREIGN KEY ( time_id )
        REFERENCES time_e ( time_id ),
    CONSTRAINT item_branch_fk FOREIGN KEY ( item_id )
        REFERENCES item ( item_id ),
    CONSTRAINT location_branch_fk FOREIGN KEY ( location_id )
        REFERENCES location ( location_id )
);
--Question 2
INSERT INTO branch VALUES (
    '13131',
    'Northwest',
    'General'
);

INSERT INTO branch VALUES (
    '13091',
    ' Store',
    'mall'
);

INSERT INTO branch VALUES (
    '12130',
    'New York Store',
    'Dmart'
);

INSERT INTO branch VALUES (
    '24091',
    'Indian ',
    'General'
);

INSERT INTO branch VALUES (
    '09111',
    'Dollar General',
    'Whole Sale'
);

INSERT INTO item VALUES (
    '1',
    'Clothing',
    'Pepe',
    'Western',
    'USA'
);

INSERT INTO item VALUES (
    '2',
    'Traditional',
    'VIP',
    'Clothing',
    'Indian'
);

INSERT INTO item VALUES (
    '3',
    'Mobiles',
    'Samsung',
    'electric',
    'USA '
);

INSERT INTO location VALUES (
    'Maryville',
    '1121 N',
    'Kansas',
    'Missouri',
    'USA'
);

INSERT INTO location VALUES (
    'Chicago',
    '1111 N',
    'Wall ',
    'Illinois',
    'USA'
);

INSERT INTO location VALUES (
    'St Louis',
    'Dunn ',
    'Missouri',
    'Missouri',
    'USA'
);

INSERT INTO time_e VALUES (
    '1',
    1,
    2,
    1,
    2020
);

INSERT INTO time_e VALUES (
    '2',
    1,
    3,
    1,
    2020
);

INSERT INTO time_e VALUES (
    '3',
    1,
    4,
    1,
    2020
);

INSERT INTO sales VALUES (
    '13131',
    'Maryville',
    '1',
    '1',
    13,
    213
);

INSERT INTO sales VALUES (
    '13091',
    'St Louis',
    '2',
    '2',
    09,
    319
);

INSERT INTO sales VALUES (
    '12130',
    'Chicago',
    '3',
    '3',
    9,
    139
);
--Question 3
ALTER TABLE sales MODIFY
    units_sold NUMBER(38);

ALTER TABLE sales MODIFY
    dollars_sold NUMBER(38);

--Question 4
UPDATE item
SET
    item_name = 'HAT',
    brand = 'Puma',
    type = 'Ferrari'
WHERE
    item_id = (
        SELECT
            a
        FROM
            (
                SELECT
                    ROWNUM a
                FROM
                    item
            ) tab
        WHERE
            tab.a = 3
    );

--Question 5
SELECT
    branch_id,
    location_id,
    item_id,
    units_sold,
    dollars_sold
FROM
    sales
ORDER BY
    item_id DESC;

--Question 6
SELECT
    COUNT(item_id),
    SUM(units_sold),
    SUM(dollars_sold),
    sales.location_id
FROM
    sales
GROUP BY
    sales.location_id;

--Question 7
COMMIT;

--Question 8
SELECT
    *
FROM
    location;

SELECT
    *
FROM
    branch;

SELECT
    *
FROM
    time_e;

SELECT
    *
FROM
    item;

SELECT
    *
FROM
    sales;

--Question 9
DROP TABLE sales;

DROP TABLE branch;

DROP TABLE location;

DROP TABLE time_e;

DROP TABLE item;

--Question 10
ROLLBACK;

--Question 11
SELECT
    *
FROM
    location;

SELECT
    *
FROM
    branch;

SELECT
    *
FROM
    time_e;

SELECT
    *
FROM
    item;

SELECT
    *
FROM
    sales;

--Question 12
/*

Drop is an auto commit which when we dropped table we cannot fetch back as it will be deleted from the database.
So, after we run a select command, we will get an error messgae stating no table exist in the DB.

*/