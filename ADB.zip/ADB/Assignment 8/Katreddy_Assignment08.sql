drop table MyFoodDestination;

create table MyFoodDestination(

 Place_ID NUMBER(2) PRIMARY KEY,
 Place_Name VARCHAR2(30),
 Special_Dish VARCHAR(30),
 Dish_Price NUMBER(7,2)
);

INSERT INTO myfooddestination VALUES(1,'KRITHUNGA','WINGS BIRYANI',10.00);
INSERT INTO myfooddestination VALUES(2,'CREAM STONE','ICE CREAM',10.00);
INSERT INTO myfooddestination VALUES(3,'RAYALASEEMA RUCHULU','ULAVACHARU BIRYANI',12.00);
INSERT INTO myfooddestination VALUES(4,'VARALAXMI TIFFINS','GHEE IDLI',20.00);


-- ANSWER 1 --
CREATE OR REPLACE PROCEDURE special_dish IS
    dish  VARCHAR2(30);
    place VARCHAR2(30);
BEGIN
    place := '&place';
    SELECT
        special_dish
    INTO dish
    FROM
        myfooddestination
    WHERE
        place_name = place;

    dbms_output.put_line('The special dish in '
                         || place
                         || ' is '
                         || dish);
EXCEPTION
    WHEN no_data_found THEN
        dbms_output.put_line('I don’t have any special dish in ' || place);
END;

EXEC special_dish;


-- ANSWER 2 --
CREATE OR REPLACE FUNCTION findaverage RETURN NUMBER IS
    average NUMBER;
BEGIN
    SELECT
        AVG(dish_price)
    INTO average
    FROM
        myfooddestination;

    RETURN average;
END;


-- ANSWER 3 --
CREATE OR REPLACE PROCEDURE printaverage AS
BEGIN
    dbms_output.put_line('The average value is ' || findaverage);
END;

EXEC printaverage;

-- ANSWER 4 --
CREATE OR REPLACE FUNCTION findmax RETURN NUMBER IS
    maximum NUMBER;
BEGIN
    SELECT
        MAX(dish_price)
    INTO maximum
    FROM
        myfooddestination;

    RETURN maximum;
END;


-- ANSWER 5 --
CREATE OR REPLACE PROCEDURE printmax AS
    dish VARCHAR2(30);
BEGIN
    SELECT
        special_dish
    INTO dish
    FROM
        myfooddestination
    WHERE
        dish_price = findmax;

    dbms_output.put_line('The name of the dish with maximum  price is '
                         || dish
                         || ' and the price is '
                         || findmax);
END;

EXEC printmax;